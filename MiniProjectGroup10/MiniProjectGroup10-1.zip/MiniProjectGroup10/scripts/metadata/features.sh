#!/bin/bash
# Display the first line of the CSV file to show column headers
head -1 "./data/Fortune 1000 Companies by Revenue.csv"

#./scripts/metadata/features.sh